﻿using System;

namespace WpfApp1.Models
{
    public class VideoItem
    {
        public string Name { get; set; }
        public long Offset { get; set; }
        public int Size { get; set; }
        public string StartDateTime { get; set; }
    }
}
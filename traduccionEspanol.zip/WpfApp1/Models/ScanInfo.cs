﻿namespace WpfApp1.Models
{
    public class ScanInfo
    {
        public int TotalCount { get; set; }
        public string MinDateTime { get; set; }
        public string MaxDateTime { get; set; }
    }
}
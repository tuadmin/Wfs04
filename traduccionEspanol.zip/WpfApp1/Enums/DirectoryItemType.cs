﻿namespace WpfApp1.Enums
{
    public enum DirectoryItemType
    {
        Drive,
        Folder,
        File
    }
}